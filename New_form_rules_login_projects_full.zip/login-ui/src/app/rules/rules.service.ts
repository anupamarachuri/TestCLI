// RulesService stub
