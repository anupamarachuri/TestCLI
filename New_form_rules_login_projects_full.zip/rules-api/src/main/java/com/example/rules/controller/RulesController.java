
@RestController
@RequestMapping("/api/rules")
public class RulesController {
    @Autowired private RulesService rulesService;
    @GetMapping("/config/{formName}")
    public ResponseEntity<?> getRules(@PathVariable String formName) throws IOException {
        return ResponseEntity.ok(rulesService.getRulesConfig(formName));
    }
    @PostMapping("/evaluate")
    public ResponseEntity<?> evaluate(@RequestBody Map<String, Object> request) throws IOException {
        String form = (String) request.get("form");
        Map<String, Object> data = (Map<String, Object>) request.get("data");
        Map<String, String> errors = rulesService.evaluate(form, data);
        return ResponseEntity.ok(Map.of("isValid", errors.isEmpty(), "errors", errors));
    }
}
