// Stub for RuleEvalRequest.java
