
@RestController
@RequestMapping("/api/forms")
public class FormConfigController {
    @Autowired private FormConfigService service;
    @GetMapping("/config/{formName}")
    public ResponseEntity<?> getFormConfig(@PathVariable String formName) throws IOException {
        return ResponseEntity.ok(service.loadFormConfig(formName));
    }
}
