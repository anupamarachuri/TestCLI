// Stub for LoginPlugin.java
