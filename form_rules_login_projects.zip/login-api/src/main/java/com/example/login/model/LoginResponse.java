// Stub for LoginResponse.java
