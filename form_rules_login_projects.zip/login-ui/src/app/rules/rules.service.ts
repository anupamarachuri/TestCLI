// RulesService Stub
