// Stub for LoginRequest.java
