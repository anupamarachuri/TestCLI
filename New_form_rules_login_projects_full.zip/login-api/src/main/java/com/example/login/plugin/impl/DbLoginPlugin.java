
@Component
public class DbLoginPlugin implements LoginPlugin {
    public boolean supports(String loginType) {
        return "db".equalsIgnoreCase(loginType);
    }
    public LoginResponse authenticate(String username, String password) {
        if ("admin".equals(username) && "admin123".equals(password)) {
            return new LoginResponse(true, "Login successful", "mock-token");
        }
        return new LoginResponse(false, "Invalid credentials", null);
    }
}
