// LoginModule declaration
