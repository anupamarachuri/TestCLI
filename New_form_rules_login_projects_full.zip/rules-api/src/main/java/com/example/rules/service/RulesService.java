
@Service
public class RulesService {
    public Map<String, Object> getRulesConfig(String formName) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        InputStream is = getClass().getClassLoader().getResourceAsStream("rules/" + formName + ".json");
        return mapper.readValue(is, new TypeReference<>() {});
    }

    public Map<String, String> evaluate(String formName, Map<String, Object> data) throws IOException {
        Map<String, Object> rules = getRulesConfig(formName);
        Map<String, Map<String, Object>> fields = (Map<String, Map<String, Object>>) rules.get("fields");
        Map<String, String> errors = new HashMap<>();

        for (String field : fields.keySet()) {
            Object value = data.get(field);
            Map<String, Object> rule = fields.get(field);

            if (Boolean.TRUE.equals(rule.get("required")) && (value == null || value.toString().isEmpty())) {
                errors.put(field, field + " is required");
            }
            if (rule.containsKey("pattern") && value != null) {
                String pattern = (String) rule.get("pattern");
                if (!Pattern.matches(pattern, value.toString())) {
                    errors.put(field, field + " is invalid");
                }
            }
        }
        return errors;
    }
}
