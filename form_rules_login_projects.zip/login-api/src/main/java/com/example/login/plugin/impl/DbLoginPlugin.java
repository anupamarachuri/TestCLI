// Stub for DbLoginPlugin.java
