
@Service
public class LoginService {
    private final List<LoginPlugin> plugins;
    public LoginService(List<LoginPlugin> plugins) {
        this.plugins = plugins;
    }
    public LoginResponse login(String type, String username, String password) {
        return plugins.stream()
            .filter(p -> p.supports(type))
            .findFirst()
            .orElseThrow(() -> new IllegalArgumentException("Unsupported login type"))
            .authenticate(username, password);
    }
}
