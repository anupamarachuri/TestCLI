// RulesModule stub
