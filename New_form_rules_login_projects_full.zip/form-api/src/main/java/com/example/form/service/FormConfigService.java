
@Service
public class FormConfigService {
    public Map<String, Object> loadFormConfig(String formName) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        InputStream is = getClass().getClassLoader().getResourceAsStream("forms/" + formName + ".schema.json");
        return mapper.readValue(is, new TypeReference<>() {});
    }
}
