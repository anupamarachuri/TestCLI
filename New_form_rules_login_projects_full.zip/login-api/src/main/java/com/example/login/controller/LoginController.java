
@RestController
@RequestMapping("/api/login")
public class LoginController {
    @Autowired private LoginService loginService;
    @PostMapping("/{type}")
    public ResponseEntity<LoginResponse> login(@PathVariable String type, @RequestBody LoginRequest request) {
        return ResponseEntity.ok(loginService.login(type, request.getUsername(), request.getPassword()));
    }
}
