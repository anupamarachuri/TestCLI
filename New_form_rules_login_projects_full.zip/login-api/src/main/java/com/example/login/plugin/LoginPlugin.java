
public interface LoginPlugin {
    boolean supports(String loginType);
    LoginResponse authenticate(String username, String password);
}
