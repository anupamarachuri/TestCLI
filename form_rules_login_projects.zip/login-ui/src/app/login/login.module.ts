// Angular LoginModule using FormsModule and RulesModule
